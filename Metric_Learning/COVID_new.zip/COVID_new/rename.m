

clear;
file = dir('C:\Users\hunter\Desktop\Courses\Deep Learning\Lab6-covid19\COVID_new\tuber\*.jpg');
len = length(file)
filename = [];
AA = [];
for i = 1 : len
   AA = [AA, strcat('"TUBER_', num2str(i), '",')];
   oldname = file(i).name;
   filename = [filename, strcat('"TUBER_', oldname(1:end-4), '",')];
   newname = strcat('TUBER_', num2str(i),'.jpg');
   movefile(oldname, newname);
end
ha = 1;

